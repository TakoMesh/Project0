# Project 0
This is an informational webpage about conductor Mirian Khukhunaishvili.
home.html is the file which opens the home page of the webpage.
There is a menu bar to go to different pages.
In Schedule there is a table of upcoming and past concerts and notes if upcoming
concert is today or it is cancelled / postponed.
In Gallery, you can see pictures and videos of Mirian.
In Contact, you can write an email to Mirian. 
Web Programming with Python and JavaScript
